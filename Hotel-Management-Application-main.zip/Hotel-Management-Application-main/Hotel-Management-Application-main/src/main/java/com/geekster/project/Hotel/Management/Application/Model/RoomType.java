package com.geekster.project.Hotel.Management.Application.Model;

public enum RoomType {
    AC, NON_AC
}
