package com.geekster.project.Hotel.Management.Application.Model;

import jakarta.persistence.*;

@Entity
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roomId;
    private Integer roomNo;
    @Enumerated(EnumType.STRING)
    private RoomType roomType;
    private Double roomPrice;
    private Boolean roomAvailableStatus;
    
	public Room() {
		super();
	}
	public Room(Long roomId, Integer roomNo, RoomType roomType, Double roomPrice, Boolean roomAvailableStatus) {
		super();
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.roomPrice = roomPrice;
		this.roomAvailableStatus = roomAvailableStatus;
	}
	public Long getRoomId() {
		return roomId;
	}
	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public RoomType getRoomType() {
		return roomType;
	}
	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}
	public Double getRoomPrice() {
		return roomPrice;
	}
	public void setRoomPrice(Double roomPrice) {
		this.roomPrice = roomPrice;
	}
	public Boolean getRoomAvailableStatus() {
		return roomAvailableStatus;
	}
	public void setRoomAvailableStatus(Boolean roomAvailableStatus) {
		this.roomAvailableStatus = roomAvailableStatus;
	}

	
    
}
