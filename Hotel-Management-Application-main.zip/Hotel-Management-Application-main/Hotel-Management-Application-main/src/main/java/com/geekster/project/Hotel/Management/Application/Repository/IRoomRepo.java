package com.geekster.project.Hotel.Management.Application.Repository;

import com.geekster.project.Hotel.Management.Application.Model.Room;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IRoomRepo extends CrudRepository<Room, Long> {
}
