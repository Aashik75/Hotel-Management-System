package com.geekster.project.Hotel.Management.Application.Controller;

import com.geekster.project.Hotel.Management.Application.Model.Room;
import com.geekster.project.Hotel.Management.Application.Service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class RoomController {

    @Autowired
    RoomService roomService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/rooms")
    public String getAllRooms(Model model) {
        List<Room> rooms = roomService.getAllRooms();
        model.addAttribute("rooms", rooms);
        return "rooms";
    }

    @GetMapping("/room/add")
    public String addRoomForm(Model model) {
        model.addAttribute("room", new Room());
        return "addRoom";
    }

    @PostMapping("/room/add")
    public String addRoom(@ModelAttribute Room room) {
        roomService.addRoom(room);
        return "redirect:/rooms";
    }

    @GetMapping("/room/edit/{id}")
    public String editRoomForm(@PathVariable Long id, Model model) {
        Room room = roomService.getRoomById(id).orElseThrow(() -> new IllegalArgumentException("Invalid room Id:" + id));
        model.addAttribute("room", room);
        return "editRoom";
    }

    @PostMapping("/room/edit/{id}")
    public String editRoom(@PathVariable Long id, @ModelAttribute Room room) {
        roomService.updateRoom(id, room);
        return "redirect:/rooms";
    }

    @PostMapping("/room/delete/{id}")
    public String deleteRoom(@PathVariable Long id) {
        roomService.deleteRoomById(id);
        return "redirect:/rooms";
    }
}
