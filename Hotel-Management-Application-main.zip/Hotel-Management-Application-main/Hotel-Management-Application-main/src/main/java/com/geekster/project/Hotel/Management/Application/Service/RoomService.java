package com.geekster.project.Hotel.Management.Application.Service;

import com.geekster.project.Hotel.Management.Application.Model.Room;
import com.geekster.project.Hotel.Management.Application.Repository.IRoomRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {
    @Autowired
    IRoomRepo roomRepo;

    public List<Room> getAllRooms() {
        return (List<Room>) roomRepo.findAll();
    }

    public void addRoom(Room room) {
        roomRepo.save(room);
    }

    public Optional<Room> getRoomById(Long id) {
        return roomRepo.findById(id);
    }

    public void updateRoom(Long id, Room room) {
        Room existingRoom = roomRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid room Id:" + id));
        existingRoom.setRoomNo(room.getRoomNo());
        existingRoom.setRoomType(room.getRoomType());
        existingRoom.setRoomPrice(room.getRoomPrice());
        existingRoom.setRoomAvailableStatus(room.getRoomAvailableStatus());
        roomRepo.save(existingRoom);
    }

    public void deleteRoomById(Long id) {
        roomRepo.deleteById(id);
    }
}
